package testyselenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestySelenium {
  
    WebDriver driver = new ChromeDriver();
    int zaliczoneTesty = 0;
              
	public void test1(){  
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.manage().window().maximize();
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("01-12-2020");
		driver.findElement(By.id("rodzice")).click();
		driver.findElement(By.id("lekarz")).click();
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Brak")>0){
			zaliczoneTesty ++;
			System.out.println("Test1 zaliczony ");

		}
		else{
			System.out.println("Test1 niezaliczony");
		}  
	}

	public void test2(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("01-01-2011");
		driver.findElement(By.id("rodzice")).click();
		driver.findElement(By.id("lekarz")).click();
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Brak")>0){
			zaliczoneTesty ++;
			System.out.println("Test2 zaliczony ");

		}
		else{
			System.out.println("Test2 niezaliczony");
		} 
	}

	public void test3(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("30-12-2010");
		driver.findElement(By.id("rodzice")).click();
		driver.findElement(By.id("lekarz")).click();
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Mlodzik")>0){
			zaliczoneTesty ++;
			System.out.println("Test3 zaliczony ");

		}
		else{
			System.out.println("Test3 niezaliczony");
		} 
	}

	public void test4(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("01-01-2010");
		driver.findElement(By.id("rodzice")).click();
		driver.findElement(By.id("lekarz")).click();
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Mlodzik")>0){
			zaliczoneTesty ++;
			System.out.println("Test4 zaliczony ");

		}
		else{
			System.out.println("Test4 niezaliczony");
		} 
	}

	public void test5(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("01-01-2007");
		driver.findElement(By.id("rodzice")).click();
		driver.findElement(By.id("lekarz")).click();
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Mlodzik")>0){
			zaliczoneTesty ++;
			System.out.println("Test5 zaliczony ");

		}
		else{
			System.out.println("Test5 niezaliczony");
		} 
	}

	public void test6(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("01-01-2007");
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Blad")>0){
			zaliczoneTesty ++;
			System.out.println("Test6 zaliczony ");

		}
		else{
			System.out.println("Test6 niezaliczony");
		} 
	}

	public void test7(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("30-12-2006");
		driver.findElement(By.id("rodzice")).click();
		driver.findElement(By.id("lekarz")).click();
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
					String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Junior")>0){
			zaliczoneTesty ++;
			System.out.println("Test7 zaliczony ");

		}
		else{
			System.out.println("Test7 niezaliczony");
		} 
	}

	public void test8(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("01-01-2006");
		driver.findElement(By.id("rodzice")).click();
		driver.findElement(By.id("lekarz")).click();
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Junior")>0){
			zaliczoneTesty ++;
			System.out.println("Test8 zaliczony ");

		}
		else{
			System.out.println("Test8 niezaliczony");
		}
	}

	public void test9(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("01-01-2003");
		driver.findElement(By.id("rodzice")).click();
		driver.findElement(By.id("lekarz")).click();
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
					String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Junior")>0){
			zaliczoneTesty ++;
			System.out.println("Test9 zaliczony ");

		}
		else{
			System.out.println("Test9 niezaliczony");
		} 
	}

	public void test10(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("30-12-2002");
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Dorosly")>0){
			zaliczoneTesty ++;
			System.out.println("Test10 zaliczony ");

		}
		else{
			System.out.println("Test10 niezaliczony");
		} 
	}

	public void test11(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("01-01-2002");
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Dorosly")>0){
			zaliczoneTesty ++;
			System.out.println("Test11 zaliczony ");

		}
		else{
			System.out.println("Test11 niezaliczony");
		}
	}

	public void test12(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("01-01-2002");
		driver.findElement(By.id("rodzice")).click();
		driver.findElement(By.id("lekarz")).click();
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Blad")>0){
			zaliczoneTesty ++;
			System.out.println("Test12 zaliczony ");

		}
		else{
			System.out.println("Test12 niezaliczony");
		}
	}

	public void test13(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("01-01-1980");
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Dorosly")>0){
			zaliczoneTesty ++;
			System.out.println("Test13 zaliczony ");

		}
		else{
			System.out.println("Test13 niezaliczony");
		}
	}

	public void test14(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("01-01-1956");
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Dorosly")>0){
			zaliczoneTesty ++;
			System.out.println("Test14 zaliczony ");

		}
		else{
			System.out.println("Test14 niezaliczony");
		}
	}

	public void test15(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("30-12-1955");
		driver.findElement(By.id("lekarz")).click();
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Senior")>0){
			zaliczoneTesty ++;
			System.out.println("Test15 zaliczony ");

		}
		else{
			System.out.println("Test15 niezaliczony");
		}
	}

	public void test16(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("01-01-1955");
		driver.findElement(By.id("lekarz")).click();
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Senior")>0){
			zaliczoneTesty ++;
			System.out.println("Test16 zaliczony ");

		}
		else{
			System.out.println("Test16 niezaliczony");
		}
	}

	public void test17(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("06-05-1944");
		driver.findElement(By.id("lekarz")).click();
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Senior")>0){
			zaliczoneTesty ++;
			System.out.println("Test17 zaliczony ");

		}
		else{
			System.out.println("Test17 niezaliczony");
		}
	}

	public void test18(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("01-01-1955");
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Blad")>0){
			zaliczoneTesty ++;
			System.out.println("Test18 zaliczony ");

		}
		else{
			System.out.println("Test18 niezaliczony");
		}
	}

	public void test19(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Lukas");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("12-10-1800");
		driver.findElement(By.id("lekarz")).click();
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Blad")>0){
			zaliczoneTesty ++;
			System.out.println("Test19 zaliczony ");

		}
		else{
			System.out.println("Test19 niezaliczony");
		}
	}

	public void test20(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("12222");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("12-12-1999");
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Blad")>0){
			zaliczoneTesty ++;
			System.out.println("Test20 zaliczony ");

		}
		else{
			System.out.println("Test20 niezaliczony");
		}
	}

	public void test21(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Karol");
		driver.findElement(By.id("inputPassword3")).sendKeys("22241254");
		driver.findElement(By.id("dataU")).sendKeys("12-12-1999");
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Blad")>0){
			zaliczoneTesty ++;
			System.out.println("Test21 zaliczony ");

		}
		else{
			System.out.println("Test21 niezaliczony");
		}
	}

	public void test22(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Karol");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("assasad");
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Blad")>0){
			zaliczoneTesty ++;
			System.out.println("Test22 zaliczony ");

		}
		else{
			System.out.println("Test22 niezaliczony");
		}
	}

	public void test23(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Karol");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("1");
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Blad")>0){
			zaliczoneTesty ++;
			System.out.println("Test23 zaliczony ");

		}
		else{
			System.out.println("Test23 niezaliczony");
		}
	}

	public void test24(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Karol");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("2000");
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
					String   odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Blad")>0){
			zaliczoneTesty ++;
			System.out.println("Test24 zaliczony ");

		}
		else{
			System.out.println("Test24 niezaliczony");
		}
	}

	public void test25(){
		driver.get("https://lamp.ii.us.edu.pl/~mtdyd/zawody/");
		driver.findElement(By.id("inputEmail3")).sendKeys("Karol");
		driver.findElement(By.id("inputPassword3")).sendKeys("Nowak");
		driver.findElement(By.id("dataU")).sendKeys("44-22-2000");
		driver.findElement(By.xpath("//button[@type='button']")).click();
		driver.switchTo().alert().accept();
		driver.switchTo().alert().accept();
		String odpowiedz = driver.findElement(By.id("returnSt")).getText();
		if(odpowiedz.indexOf("Blad")>0){
			zaliczoneTesty ++;
			System.out.println("Test25 zaliczony ");

		}
		else{
			System.out.println("Test25 niezaliczony");
		}
	}

    public static void main(String[] args) throws InterruptedException {
        
        System.setProperty("webdriver.chrome.driver", "F:\\GUIjava\\TestySelenium\\src\\testyselenium\\chromedriver.exe");
        
        TestySelenium testy = new TestySelenium();
        testy.test1();
        testy.test2();
        testy.test3();
        testy.test4();
        testy.test5();
        testy.test6();
        testy.test7();
        testy.test8();
        testy.test9();
        testy.test10();
        testy.test11();
        testy.test12();
        testy.test13();
        testy.test14();
        testy.test15();
        testy.test16();
        testy.test17();
        testy.test18();
        testy.test19();
        testy.test20();
        testy.test21();
        testy.test22();
        testy.test23();
        testy.test24();
        testy.test25();
        
        System.out.println("Łącznie testów zaliczonych: "+ testy.zaliczoneTesty + "/25");
        Thread.sleep(2000);
        testy.driver.close();
        
	
    }
    
}
